<?= $this->uri->segment(2); ?>
<h1>selamat Datang di halaman Dashboard</h1>
<?= $this->session->userdata('nama'); ?>